
import os
import telebot
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton, ReplyKeyboardMarkup, KeyboardButton, ReplyKeyboardRemove

TOKEN = os.getenv("TOKEN")  # قراءة التوكن من متغير البيئة
if not TOKEN:
    raise ValueError("ERROR: TOKEN environment variable is not set.")

bot = telebot.TeleBot(TOKEN)

student_list = []
registration_open = True
last_list_message_id = None
last_list_chat_id = None

def get_main_buttons():
    markup = InlineKeyboardMarkup(row_width=1)
    markup.add(
        InlineKeyboardButton("✅ سجل اسمي", callback_data="register"),
        InlineKeyboardButton("❌ احذف اسمي", callback_data="remove"),
        InlineKeyboardButton("🎧 مستمعة", callback_data="listener")
    )
    return markup

def get_admin_keyboard():
    markup = ReplyKeyboardMarkup(resize_keyboard=True, row_width=1)
    markup.add(
        KeyboardButton("/start"),
        KeyboardButton("/stop"),
        KeyboardButton("/stopdefinitely")
    )
    return markup

def is_admin(message):
    try:
        member = bot.get_chat_member(message.chat.id, message.from_user.id)
        return member.status in ['administrator', 'creator']
    except:
        return False

def send_or_edit_list(chat_id):
    global last_list_message_id, last_list_chat_id
    if not student_list:
        text = "📋 قائمة طالبات أكاديمية الرحمة 📋\n\n(القائمة فارغة حالياً)"
    else:
        text = "📋 قائمة طالبات أكاديمية الرحمة 📋\n\n"
        for i, name in enumerate(student_list, 1):
            text += f"{i}. {name}\n"

    if last_list_message_id and last_list_chat_id == chat_id:
        try:
            bot.edit_message_text(chat_id=chat_id,
                                  message_id=last_list_message_id,
                                  text=text,
                                  reply_markup=get_main_buttons())
        except:
            msg = bot.send_message(chat_id, text, reply_markup=get_main_buttons())
            global last_list_message_id, last_list_chat_id
            last_list_message_id = msg.message_id
            last_list_chat_id = chat_id
    else:
        msg = bot.send_message(chat_id, text, reply_markup=get_main_buttons())
        global last_list_message_id, last_list_chat_id
        last_list_message_id = msg.message_id
        last_list_chat_id = chat_id

@bot.message_handler(commands=['start'])
def handle_start(message):
    if is_admin(message):
        bot.send_message(
            message.chat.id,
            "✅ تم تشغيل القائمة الإلكترونية.\n🔐 البوت آمن ولا يرسل رسائل مزعجة.",
            reply_markup=get_admin_keyboard()
        )
    else:
        bot.send_message(
            message.chat.id,
            "✅ مرحبًا بك! اضغط على أحد الأزرار أدناه للتسجيل أو الحذف.",
            reply_markup=ReplyKeyboardRemove()
        )
    send_or_edit_list(message.chat.id)

@bot.message_handler(commands=['stop'])
def handle_stop(message):
    global registration_open
    if is_admin(message):
        registration_open = False
        bot.reply_to(message, "🚫 تم إيقاف التسجيل مؤقتًا.")
    else:
        bot.reply_to(message, "❌ هذا الأمر للمشرفين فقط.")

@bot.message_handler(commands=['stopdefinitely'])
def handle_stopdefinitely(message):
    global registration_open, student_list
    if is_admin(message):
        student_list.clear()
        registration_open = True
        bot.reply_to(message, "♻️ تم مسح القائمة بالكامل وإعادة فتح التسجيل.")
        send_or_edit_list(message.chat.id)
    else:
        bot.reply_to(message, "❌ هذا الأمر للمشرفين فقط.")

@bot.callback_query_handler(func=lambda call: True)
def handle_callback(call):
    global student_list
    user = call.from_user
    username = f"{user.first_name} {(user.last_name or '')}".strip()

    if call.data == "register":
        if not registration_open:
            bot.answer_callback_query(call.id, "🚫 التسجيل مغلق حالياً.")
            return
        if any(username in entry for entry in student_list):
            bot.answer_callback_query(call.id, "⚠️ أنت مسجل بالفعل. لا يمكنك التسجيل مرتين.")
            return
        entry = f"{username} #"
        student_list.append(entry)
        bot.answer_callback_query(call.id, "✅ تم تسجيل اسمك.")

    elif call.data == "remove":
        to_remove = None
        for entry in student_list:
            if username in entry:
                to_remove = entry
                break
        if to_remove:
            student_list.remove(to_remove)
            bot.answer_callback_query(call.id, "🗑️ تم حذف اسمك.")
        else:
            bot.answer_callback_query(call.id, "❌ اسمك غير موجود.")

    elif call.data == "listener":
        if not registration_open:
            bot.answer_callback_query(call.id, "🚫 التسجيل مغلق حالياً.")
            return
        if any(username in entry for entry in student_list):
            bot.answer_callback_query(call.id, "⚠️ أنت مسجل بالفعل. لا يمكنك التسجيل مرتين.")
            return
        entry = f"{username} 🎧"
        student_list.append(entry)
        bot.answer_callback_query(call.id, "🎧 تم تسجيلك كمستمعة.")

    try:
        bot.edit_message_reply_markup(chat_id=call.message.chat.id,
                                      message_id=call.message.message_id,
                                      reply_markup=None)
    except:
        pass
    send_or_edit_list(call.message.chat.id)

print("🤖 البوت يعمل الآن...")
bot.infinity_polling()
